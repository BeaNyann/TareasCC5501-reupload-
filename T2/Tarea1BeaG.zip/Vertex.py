# Un vértice
# Contiene los puntos de su coordenada
class Vertex:
    def __init__(self, x, y):
        self.x = x
        self.y = y