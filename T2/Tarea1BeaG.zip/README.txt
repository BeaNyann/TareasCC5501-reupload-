Hola! para correr mi tarea pon
"python Triangulation.py"
en la consola y ahí el programa te va a decir que hacer
Pero de todas formas, puedes:
* ingresar los puntos a mano
* indicar el nombre de un csv (vienen 3 incluidos en la entrega)
* indicar que deseas puntos aleatorios, definiendo la cantidad y los limites

Si en la pregunta sobre mostrar el paso a paso indicaste que si
Para avanzar el siguiente paso tienes que cerrar el pop up que se abrió